### Version 8.0.0.0

* Updated for WoW 8.0

### Version 7.3.5.0

* Fixed debuff timers sometimes failing to appear (#11)
