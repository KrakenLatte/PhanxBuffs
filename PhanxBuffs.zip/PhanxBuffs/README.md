PhanxBuffs
=============

**EN** — Basic replacement for the player buff, debuff, and temporary enchant frames.  
**DE** — Einfacher Ersatz für die Stärkungszauber-, Schwächungszauber- und Waffenverzauberungssymbole des Spielers.  
**ES** — Sustitutos básicos de los iconos del jugador de beneficios, perjuicios y encancamientos de armas.  
**PT** — Substituições básicas para os ícones do jogador de bônus, penalidades e encantamentos de armas.  
**RU** — Простая замена иконки игрока баффы, дебаффы и чары, связанных с оружием.  
**ZH-TW** — 基本的玩家增益、減益、與武器暫時附魔框架的替代品。

* [Download from Curse](https://www.curseforge.com/wow/addons/phanxbuffs)
* [Download from WoWInterface](https://www.wowinterface.com/downloads/info16874-PhanxBuffs.html)
